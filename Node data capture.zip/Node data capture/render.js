const WebSocket = require('websocket').client;
const fs = require('fs'); // Import the Node.js file system module

const client = new WebSocket();

client.on('connectFailed', (error) => {
  console.log(`Connect Error: ${error.toString()}`);
});

client.on('connect', (connection) => {
  console.log('WebSocket Client Connected');

  connection.on('error', (error) => {
    console.log(`Connection Error: ${error.toString()}`);
  });

  connection.on('close', () => {
    console.log('Connection Closed');
  });

  connection.on('message', (message) => {
    if (message.type === 'utf8') {
      const receivedData = message.utf8Data;

      // Check for different message types and parse accordingly
      if (receivedData.includes('LiDAR Distance')) {
        // LiDAR data message: "Pan: <panPos> | Tilt: <tiltPos> | LiDAR Distance: <distance>"
        const dataParts = receivedData.split(' | ');
        const x = parseFloat(dataParts[0].split(': ')[1]);
        const y = parseFloat(dataParts[1].split(': ')[1]);
        const z = parseFloat(dataParts[2].split(': ')[1]);

        //Convert polar coordinates to Cartesian coordinates (assuming spherical LiDAR data)
        //  const x = distanceData * Math.cos(panData * Math.PI / 180) * Math.cos(tiltData * Math.PI / 180);
        //  const y = distanceData * Math.cos(panData * Math.PI / 180) * Math.sin(tiltData * Math.PI / 180);
        //  const z = distanceData * Math.cos(tiltData * Math.PI / 180);
        // panData = (pan * Math.PI) / 180; // Convert pan angle to radians
        // tiltData = (tilt * Math.PI) / 180; // Convert tilt angle to radians


        // const x = distanceData * Math.cos(tiltData) * Math.cos(panData);
        // const y = distanceData * Math.cos(tiltData) * Math.sin(panData);
        // const z = distanceData * Math.sin(tiltData);


//         const x = Math.abs(distanceData) * Math.sin(panData * Math.PI / 180) * Math.cos(tiltData * Math.PI / 180);
// const y = Math.abs(distanceData) * Math.sin(panData * Math.PI / 180) * Math.sin(tiltData * Math.PI / 180);
// const z = Math.abs(distanceData) * Math.sin(tiltData * Math.PI / 180);



        // Prepare data string to append to the file
        const dataString = `${x},${y},${z};\n`;

        // Append LiDAR data to an existing file named 'data.json'
        fs.appendFile('data1.json', dataString, (err) => {
          if (err) {
            console.error('Error appending data to file:', err);
          } else {
            console.log('LiDAR data appended to data.json');
          }
        });
      }
    }
  });
});

// Replace '192.168.0.94' with your ESP32 IP address
client.connect('ws://192.168.102.72:81/');
