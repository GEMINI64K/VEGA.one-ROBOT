const WebSocket = require('websocket').client;
const fs = require('fs'); // Import the Node.js file system module

const client = new WebSocket();

client.on('connectFailed', (error) => {
  console.log(`Connect Error: ${error.toString()}`);
});

client.on('connect', (connection) => {
  console.log('WebSocket Client Connected');

  connection.on('error', (error) => {
    console.log(`Connection Error: ${error.toString()}`);
  });

  connection.on('close', () => {
    console.log('Connection Closed');
  });

  connection.on('message', (message) => {
    if (message.type === 'utf8') {
      const receivedData = message.utf8Data;

      // Check for different message types and parse accordingly
      if (receivedData.includes('LiDAR Distance')) {
        // LiDAR data message: "Pan: <panPos> | Tilt: <tiltPos> | LiDAR Distance: <distance>"
        const dataParts = receivedData.split(' | ');
        const x = parseFloat(dataParts[0].split(': ')[1]);
        const y = parseFloat(dataParts[1].split(': ')[1]);
        const z = parseFloat(dataParts[2].split(': ')[1]);

        // Prepare data string to append to the file
        const dataString = `${x},${y},${z};\n`;

        // Append LiDAR data to an existing file or create new file named 'data.json'
        fs.appendFile('data.json', dataString, (err) => {
          if (err) {
            console.error('Error appending data to file:', err);
          } else {
            console.log('LiDAR data appended to data.json');
          }
        });
      }
    }
  });
});

// Replace '111.111.111.0.0' with your ESP32 IP address
client.connect('ws://111.111.111.0.0:81/');
